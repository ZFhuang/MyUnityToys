﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene : MonoBehaviour
{
    private float offsetX = 1.15f;
    private float offsetY = 1.15f;
    private Bricks[,] Pan = new Bricks[10, 10];
    [SerializeField]
    private Sprite[] images;
    [SerializeField]
    private Bricks OriginBricks;
    private Bricks _first = null;
    private Bricks _second = null;
    private int _score = 0;
    private Vector3 startPos;
    private int maxIndex = 0;
    private int minIndex = 0;
    private float loader = 0.5f;
    private float loadTime = 0;
    
    [SerializeField]
    private TextMesh scoreLabel;
    [SerializeField]
    private TextMesh timeLabel;

    public void wait(int inp)
    {
        if (maxIndex == 0)
        {
            maxIndex = inp;
            minIndex = inp;
        }
        if (inp > maxIndex)
        {
            maxIndex = inp;
        }
        if (inp <= minIndex)
        {
            minIndex = inp;
        }
    }
    public void score()
    {
        _score++;
        scoreLabel.text = "Score: " + _score;
    }
    public IEnumerator Boom()
    {
        int hasBoom = 0;
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                hasBoom += ifBoom(i, j);
            }
        }
        if (hasBoom == 0)
        {
            maxIndex = 0;
            minIndex = 0;
            yield break;
        }
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (Pan[i, j].end())
                {
                    Pan[i, j] = null;
                }
            }
        }
        StartCoroutine(roll((maxIndex - minIndex) / 2));
        yield return new WaitForSeconds((maxIndex - minIndex) / 2);
        maxIndex = 0;
        minIndex = 0;
        StartCoroutine(Boom());
    }
    private IEnumerator roll(float inp)
    {
        if (inp == 0)
        {
            inp = 0.7f;
        }
        for (int i = 0; i < 10; i++)
        {
            for (int j = 9; j >= 0; j--)
            {
                rolling(i, j);
            }
        }
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                Pan[i, j].control(false);
            }
        }
        yield return new WaitForSeconds(inp);
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                Pan[i, j].control(true);
            }
        }
    }
    private int ifBoom(int x, int y)
    {
        bool flag = false;
        if (x < 8)
        {
            if (Pan[x, y].id == Pan[x + 1, y].id && Pan[x + 1, y].id == Pan[x + 2, y].id)
            {
                Pan[x, y].Boom();
                Pan[x + 1, y].Boom();
                Pan[x + 2, y].Boom();
                flag = true;
            }
        }
        if (y < 8)
        {
            if (Pan[x, y].id == Pan[x, y + 1].id && Pan[x, y + 1].id == Pan[x, y + 2].id)
            {
                Pan[x, y].Boom();
                Pan[x, y + 1].Boom();
                Pan[x, y + 2].Boom();
                flag = true;
            }
        }
        if (flag)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    private void rolling(int x, int y)
    {
        if (Pan[x, y] == null)
        {
            for (int i = y; i >= 0; i--)
            {
                if (i == 0)
                {
                    Bricks target;
                    int number = Random.Range(0, 6);
                    float posX = startPos.x + offsetX * x;
                    float posY = startPos.y - offsetY * (i - 1);
                    target = Instantiate(OriginBricks) as Bricks;
                    target.transform.position = new Vector3(posX, posY, startPos.z);
                    target.SetBricks(number, images[number], x, y);
                    Pan[x, y] = target;
                    posY = startPos.y - offsetY * y;
                    Vector3 temp = new Vector3(posX, posY, startPos.z);
                    target.Move(temp);
                    return;
                }
                if (Pan[x, i - 1] != null)
                {
                    Pan[x, y] = Pan[x, i - 1];
                    Pan[x, i - 1]._Xindex = x;
                    Pan[x, i - 1]._Yindex = y;
                    Pan[x, y]._Xindex = x;
                    Pan[x, y]._Yindex = y;
                    Pan[x, i - 1] = null;
                    float posX = startPos.x + offsetX * x;
                    float posY = startPos.y - offsetY * y;
                    Vector3 temp = new Vector3(posX, posY, startPos.z);
                    Pan[x, y].Move(temp);
                    return;
                }
            }
        }
    }
    public IEnumerator Choose(Bricks inp)
    {
        if (_first == null)
        {
            _first = inp;
        }
        else
        {
            _second = inp;
            if ((Mathf.Abs(_first._Xindex - _second._Xindex) + Mathf.Abs(_first._Yindex - _second._Yindex)) == 1)
            {
                int _oldscore = _score;
                int fx, fy, sx, sy;
                fx = _first._Xindex;
                fy = _first._Yindex;
                sx = _second._Xindex;
                sy = _second._Yindex;
                Bricks temp;
                temp = Pan[_second._Xindex, _second._Yindex];
                Pan[_second._Xindex, _second._Yindex] = Pan[_first._Xindex, _first._Yindex];
                Pan[_first._Xindex, _first._Yindex] = temp;
                Pan[_first._Xindex, _first._Yindex].Move(Pan[_second._Xindex, _second._Yindex].transform.position);
                Pan[_second._Xindex, _second._Yindex].Move(Pan[_first._Xindex, _first._Yindex].transform.position);
                _first.StopRotate();
                _second.StopRotate();
                yield return new WaitForSeconds(0.35f);
                _first._Xindex = sx;
                _first._Yindex = sy;
                _second._Xindex = fx;
                _second._Yindex = fy;
                StartCoroutine(Boom());
                if (_oldscore == _score)
                {
                    Pan[sx, sy].control(true);
                    Pan[sx, sy].Move(_second.transform.position);
                    Pan[fx, fy].Move(_first.transform.position);
                }
                _first.StopRotate();
                _second.StopRotate();
                _first = null;
                _second = null;
            }
            else
            {
                _first.StopRotate();
                _second.StopRotate();
                _first = null;
                _second = null;
            }
        }
    }
    private bool moving()
    {

        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (Pan[i, j].move == true)
                {
                    return false;
                }
            }
        }
        return false;
    }
    public void Restart()
    {
        SceneManager.LoadScene("Colors");
    }

    void Start()
    {
        startPos = new Vector3(OriginBricks.transform.position.x, OriginBricks.transform.position.y, 0f);
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                Bricks news;
                int number = Random.Range(0, 6);
                float posX = startPos.x + offsetX * i;
                float posY = startPos.y - offsetY * j;
                news = Instantiate(OriginBricks) as Bricks;
                news.transform.position = new Vector3(posX, posY, startPos.z);
                news.SetBricks(number, images[number], i, j);
                Pan[i, j] = news;
            }
        }
        StartCoroutine(Boom());
    }
    void Update()
    {
        if (loader > 0)
        {
            loadTime = Time.timeSinceLevelLoad;
            if (maxIndex == 0)
            {
                loader -= Time.deltaTime;
                if (loader <= 0)
                {
                    GameObject loading = GameObject.Find("Loading");
                    loading.SetActive(false);
                    _score = 0;
                    scoreLabel.text = "Score: " + _score;
                }
            }
            else
            {
                loader = 0.5f;
            }
        }
        string time;
        time = (Time.timeSinceLevelLoad - loadTime).ToString("0.00");
        timeLabel.text = "Time: " + time;
    }
}