﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bricks : MonoBehaviour
{
    private int _id;
    private bool _control = true;
    private bool MouseIn = false;
    private float transX = 1;
    private float transY = 1;
    private bool _Boom = false;
    private bool _end = false;
    private bool _move = false;
    private bool Rotate = false;
    private Vector3 target;
    [SerializeField]
    private Scene controller;
    public bool move
    {
        get
        {
            return _move;
        }
    }

    public int _Xindex;
    public int _Yindex;
    public int id
    {
        get
        {
            return _id;
        }
    }
   

    public void SetBricks(int iid, Sprite image, int x, int y)
    {
        _id = iid;
        GetComponent<SpriteRenderer>().sprite = image;
        _Xindex = x;
        _Yindex = y;
    }
    public void OnMouseEnter()
    {
        if (_control)
        {
            MouseIn = true;
        }
    }
    public void OnMouseDown()
    {
        if (_control)
        {
            Rotate = true;
            StartCoroutine(controller.Choose(this));
        }
    }
    public void OnMouseExit()
    {
        if (_control)
        {
            MouseIn = false;
            transX = 1;
            transY = 1;
            transform.localScale = new Vector3(1, 1, 1);
        }
    }
    public void Boom()
    {
        if (_Boom == false)
        {
            _control = false;
            _Boom = true;
            controller.score();
            controller.wait(_Yindex);
        }
    }
    public bool end()
    {
        if (_Boom)
        {
            _control = false;
            transX = 1.5f;
            transY = 1.5f;
            transform.localScale = new Vector3(1.5f, 1.5f, 1);
            _end = true;
            Destroy(gameObject, 0.5f);
            return true;
        }
        return false;
    }
    public void Move(Vector3 inp)
    {
        if (inp != transform.position)
        {
            _control = false;
            target = inp;
            _move = true;
        }
    }
    public void StopRotate()
    {
        Rotate = false;
        transX = 1;
        transY = 1;
        transform.localScale = new Vector3(1, 1, 1);
        transform.rotation = new Quaternion(0, 0, 0, 1);
    }
    public void control(bool inp)
    {
        if (inp)
        {
            _control = true;
        }
        else
        {
            _control = false;
        }
    }
    
    void Start()
    {
        transX = 1;
        transY = 1;
        transform.localScale = new Vector3(1, 1, 1);
        transform.rotation = new Quaternion(0, 0, 0, 1);
    }
    void Update()
    {
        if (!_end)
        {
            if (MouseIn)
            {
                transX = Mathf.Lerp(1, 1.1f, Time.time / 0.5f);
                transY = Mathf.Lerp(1, 1.1f, Time.time / 0.5f);
                transform.localScale = new Vector3(transX, transY, 1);
            }
            if (Rotate)
            {
                transform.localScale = new Vector3(transX, transY, 2);
                transform.Rotate(Vector3.forward, Time.deltaTime * 50);
            }
            if (_move)
            {
                transform.position = Vector3.MoveTowards(transform.position, target, Time.deltaTime / 0.2f);
                if (transform.position == target)
                {
                    _control = true;
                    _move = false;
                }
            }
        }
        else
        {
            transX = Mathf.Lerp(1.1f, 0.4f, Time.time / 1.5f);
            transY = Mathf.Lerp(1.1f, 0.4f, Time.time / 1.5f);
            transform.localScale = new Vector3(transX, transY, 1);
            transform.position = new Vector3(transform.position.x, transform.position.y, 4);
        }
    }
}
