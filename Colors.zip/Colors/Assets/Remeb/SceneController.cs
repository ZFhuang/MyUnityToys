﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class SceneController : MonoBehaviour
{
    public const int gridRow = 2;
    public const int gridCol = 4;
    public const float offsetX = 2f;
    public const float offsetY = 2.5f;
    private int _score = 0;
    private Click first;
    private Click second;

    [SerializeField]
    private Click originalCard;
    [SerializeField]
    private Sprite[] images;
    [SerializeField]
    private TextMesh scoreLabel;
    [SerializeField]
    private TextMesh timeLabel;
    // Use this for initialization
    void Start()
    {
        Vector3 startPos = originalCard.transform.position;
        int[] number = { 0, 0, 1, 1, 2, 2, 3, 3 };
        number = ShuffeArray(number);
        for (int i = 0; i < gridCol; i++)
        {
            for (int j = 0; j < gridRow; j++)
            {
                Click card;
                int index = j * gridCol + i;
                int id = number[index];
                float posX = (offsetX * i) + startPos.x;
                float posY = (offsetY * j) + startPos.y;
                if (i == 0 && j == 0)
                {
                    card = originalCard;
                }
                else
                {
                    card = Instantiate(originalCard) as Click;
                }
                card.transform.position = new Vector3(posX, posY, startPos.z);
                card.SetCard(id, images[id]);
            }
        }
    }
    private int[] ShuffeArray(int[] inp)
    {
        int[] newArray = inp.Clone() as int[];
        for (int i = 0; i < newArray.Length; i++)
        {
            int a;
            a = Random.Range(i, newArray.Length);
            int temp;
            temp = newArray[i];
            newArray[i] = newArray[a];
            newArray[a] = temp;
        }
        return newArray;
    }

    public bool canReveal
    {
        get
        {
            return second == null;
        }
    }

    public void CardRevealed(Click card)
    {
        if (first == null)
        {
            first = card;
        }
        else
        {
            second = card;
            StartCoroutine(CheckMatch());
        }
    }

    public void Restart()
    {
        SceneManager.LoadScene("Remeb");
    }

    private IEnumerator CheckMatch()
    {
        if (first.id == second.id)
        {
            _score++;
            scoreLabel.text = "Score: " + _score;
        }
        else
        {
            yield return new WaitForSeconds(0.5f);
            first.Unreveal();
            second.Unreveal();
        }
        first = null;
        second = null;
    }

    // Update is called once per frame
    void Update()
    {
        if (_score < 4)
        {
            string time;
            time = (Time.timeSinceLevelLoad).ToString("0.00");
            timeLabel.text = "Time: " + time;
        }
    }
}
