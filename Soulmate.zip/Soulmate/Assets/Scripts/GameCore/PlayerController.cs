﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DragonBones;

namespace PlayerController
{
    [RequireComponent(typeof(UnityArmatureComponent))]
    class PlayerController : MonoBehaviour
    {
        private const string NORMAL_ANIMATION_GROUP = "normal";
        private const string ACTION_ANIMATION_GROUP = "action";

        public KeyCode left = KeyCode.A;
        public KeyCode right = KeyCode.D;
        public KeyCode up = KeyCode.W;
        public KeyCode down = KeyCode.S;
        public KeyCode action = KeyCode.Space;

        private const float G = -0.015f;//虽然可以改变跳跃高度，但也会改变掉落速度
        private const float GROUND = 0.0f;
        private const float JUMP_SPEED = 0.6f;
        private const float FALL_SPEED = -0.6f;
        private const float NORMALIZE_MOVE_SPEED = 0.12f;
        private const float MAX_MOVE_SPEED = NORMALIZE_MOVE_SPEED * 1.8f;
        private enum State
        {
            stand = 0,
            jump = 1,
            fall = 2,
            run = 3,
            walk = 4,
            slipFall = 5,
        }

        private State _state = State.fall;
        private bool _isGrounded = false;
        private bool _isJumpingUp = false;
        private bool _isJumpingDown = true;
        private bool _isLeftLocking = false;
        private bool _isRightLocking = false;
        private bool _isSlipingFall = false;
        private bool _isControlLocking = false;
        private int _moveDir = 0;

        private UnityArmatureComponent _armatureComponent = null;
        private Component _weaponController = null;
        private Vector2 _speed = new Vector2();

        public void isGrounded(bool inp, float posy = 0f)
        {
            if (inp == _isGrounded)
            {
                return;
            }
            if (inp == true)
            {
                _isControlLocking = false;
                _isSlipingFall = false;
                _isJumpingUp = false;
                _isJumpingDown = false;
                _speed.x = 0.0f;
                _speed.y = 0.0f;
                //transform.position = new Vector3(transform.position.x, posy + 3.9f, transform.position.z);//权宜之计
                _isGrounded = true;
            }
            else
            {
                _isGrounded = false;
                _fall();
            }
        }
        public void isWall(bool inp, float posx = 0f)
        {
            if (inp == false)
            {
                _isSlipingFall = false;
                _isLeftLocking = false;
                _isRightLocking = false;
                if (!_isGrounded)
                {
                    _state = State.fall;
                }
                return;
            }
            if (_isControlLocking)
            {
                _isControlLocking = false;
            }
            _isJumpingUp = false;
            if (transform.position.x - posx > 0f)
            {
                _isLeftLocking = true;
                //transform.position = new Vector3(posx + 3f, transform.position.y, transform.position.z);
            }
            else
            {
                _isRightLocking = true;
                //transform.position = new Vector3(posx - 3f, transform.position.y, transform.position.z);
            }
            if (!_isGrounded)
            {
                _isSlipingFall = true;
                _state = State.slipFall;
                _speed.y = -0.03f;
            }
        }

        void Start()
        {
            _armatureComponent = this.gameObject.GetComponent<UnityArmatureComponent>();
            if (GameObject.Find("FootCollider") != null)
            {
                GameObject.Find("FootCollider").AddComponent<PlayerFootCollider>();
            }
            if (GameObject.Find("HandCollider") != null)
            {
                GameObject.Find("HandCollider").AddComponent<PlayerHandCollider>();
            }
            if (GameObject.Find("PickCollider") != null)
            {
                GameObject.Find("HandCollider").AddComponent<PlayerPickCollider>();
            }

            _armatureComponent.animation.Reset();
            _armatureComponent.animation.FadeIn("stand", 0.2f, -1, 0, NORMAL_ANIMATION_GROUP);
            _updateAnimation();
        }
        private void _move(int dir)
        {
            if (_isGrounded)
            {
                if (dir == 0)
                {
                    _state = State.stand;
                    _moveDir = 0;
                    return;
                }
                _state = State.run;
            }
            if (dir == 1)
            {
                //_armatureComponent.armature.flipX = false;
                transform.localScale = new Vector3(1, 1, 1);
            }
            else if (dir == -1)
            {
                //_armatureComponent.armature.flipX = true;
                transform.localScale = new Vector3(-1, 1, 1);
            }
            _moveDir = dir;
        }
        private IEnumerator _slipJump()
        {
            _isControlLocking = true;
            if (_isLeftLocking)
            {
                _moveDir = 1;
                transform.localScale = new Vector3(1, 1, 1);
            }
            else if (_isRightLocking)
            {
                _moveDir = -1;
                transform.localScale = new Vector3(-1, 1, 1);
            }
            else
            {
                //_fall();
                yield break;
            }
            _isGrounded = false;
            _isJumpingDown = false;
            _isJumpingUp = false;
            _isSlipingFall = false;
            _jump();
            yield return new WaitForSecondsRealtime(0.2f);
            _fall();
            yield return new WaitForSecondsRealtime(0.4f);
            _isControlLocking = false;
        }
        private void _jump()
        {
            if (_isJumpingUp || _isJumpingDown)
            {
                return;
            }
            transform.position = new Vector3(transform.position.x, transform.position.y + 0.2f, transform.position.z);
            _speed.y = JUMP_SPEED;
            _isJumpingUp = true;
            _isGrounded = false;
            _state = State.jump;
        }
        private void _fall()
        {
            if (_isJumpingDown || _isGrounded)
            {
                return;
            }
            if (_speed.y >= 0)//主动掉落阈值
            {
                _isJumpingDown = true;
                _speed.y /= 2;//主动掉落减少值
                _state = State.fall;
                return;
            }
            _isJumpingDown = true;
            _speed.y = -0.03f;
            _state = State.fall;
        }
        private void _updatePosition()
        {
            //position ani
            if (_isJumpingUp)
            {
                if (_speed.y <= -0.05f)
                {
                    _fall();
                }
            }
            if (_isSlipingFall)
            {
                _state = State.slipFall;
            }

            //position cal
            var position = this.transform.localPosition;
            _speed.x = MAX_MOVE_SPEED * _moveDir;
            if (!_isGrounded && _speed.y != FALL_SPEED)
            {
                if (_isSlipingFall)
                {
                    _speed.y += G / 2 * _armatureComponent.animation.timeScale;
                }
                else
                {
                    _speed.y += G * _armatureComponent.animation.timeScale;
                }
                if (_speed.y < FALL_SPEED)
                {
                    _speed.y = FALL_SPEED;
                }
            }
            if (_speed.x != 0.0f)
            {
                position.x += _speed.x * _armatureComponent.animation.timeScale;
            }
            if (_speed.y != 0.0f)
            {
                position.y += _speed.y * _armatureComponent.animation.timeScale;
            }
            

            this.transform.localPosition = position;
        }
        private void _updateAnimation()
        {
            if (_armatureComponent.animation.lastAnimationName != _state.ToString())
            {//不知道怎么办比较好，只能大概这样
                switch (_state)
                {
                    case State.stand:
                        _armatureComponent.animation.FadeIn("stand", -1.0f, -1, 0, NORMAL_ANIMATION_GROUP);
                        break;
                    case State.jump:
                        _armatureComponent.animation.FadeIn("jump", -1.0f, -1, 0, NORMAL_ANIMATION_GROUP);
                        break;
                    case State.fall:
                        _armatureComponent.animation.FadeIn("fall", -1.0f, -1, 0, NORMAL_ANIMATION_GROUP);
                        break;
                    case State.run:
                        _armatureComponent.animation.FadeIn("run", -1.0f, -1, 0, NORMAL_ANIMATION_GROUP);
                        break;
                    case State.walk:
                        _armatureComponent.animation.FadeIn("walk", -1.0f, -1, 0, NORMAL_ANIMATION_GROUP);
                        break;
                    case State.slipFall:
                        _armatureComponent.animation.FadeIn("slipFall", -1.0f, -1, 0, NORMAL_ANIMATION_GROUP);
                        break;
                    default:
                        print("Error State!");
                        break;
                }
            }
        }

        void Update()
        {
            //Vars
            bool isLeft = false;
            bool isRight = false;
            if (!_isLeftLocking)
            {
                isLeft = Input.GetKey(left);
            }
            if (!_isRightLocking)
            {
                isRight = Input.GetKey(right);
            }

            //Controlls
            if (!_isControlLocking)
            {
                if (isLeft == isRight)
                {

                    _move(0);
                }
                else if (isLeft)
                {
                    _move(-1);
                }
                else if (isRight)
                {
                    _move(1);
                }
                if (_isSlipingFall && Input.GetKeyDown(up))
                {
                    StopCoroutine("_slipJump");
                    //要用字符串调用的协程才能用字符串停止，那有参数呢？ 
                    //IEnumerator helloIenumeratro;helloIenumeratro = testStartCoroutime(hhh);  这样？
                    StartCoroutine("_slipJump");
                }
                else if (Input.GetKeyDown(up))
                {
                    _jump();
                }
                if (Input.GetKeyUp(up))
                {
                    _fall();
                }
            }

            //Updates
            _updatePosition();
            _updateAnimation();
        }
    }

    class PlayerFootCollider : MonoBehaviour    //加Mono才能让上面的AddCom识别到。
    {
        Component Player = null;
        private void OnTriggerExit2D(Collider2D collision)
        {
            if (collision.tag == "Floor")
            {
                Player.gameObject.GetComponent<PlayerController>().isGrounded(false);
            }
        }
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.tag == "Floor")
            {
                Player.gameObject.GetComponent<PlayerController>().isGrounded(true, collision.transform.position.y);//权宜
            }
        }
        private void Start()
        {
            Player = gameObject.GetComponentInParent<PlayerController>();
        }
    }

    class PlayerHandCollider : MonoBehaviour    //加Mono才能让上面的AddCom识别到。
    {
        Component Player = null;
        private void OnTriggerExit2D(Collider2D collision)
        {
            Player.gameObject.GetComponent<PlayerController>().isWall(false);
        }
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.tag == "Floor")
            {
                Player.gameObject.GetComponent<PlayerController>().isWall(true, collision.transform.position.x);//权宜
            }
        }
        private void Start()
        {
            Player = gameObject.GetComponentInParent<PlayerController>();
        }
    }
    class PlayerPickCollider : MonoBehaviour    //加Mono才能让上面的AddCom识别到。
    {
        Component Player = null;
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.tag == "Item")
            {
                collision.gameObject.SendMessage("Get");
            }
            else if (collision.tag == "Weapon")
            {
                collision.gameObject.SendMessage("Get");
            }
        }
        private void Start()
        {
            Player = gameObject.GetComponentInParent<PlayerController>();
        }
    }
}