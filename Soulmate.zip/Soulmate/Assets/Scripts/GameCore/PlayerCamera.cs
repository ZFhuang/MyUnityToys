﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCamera : MonoBehaviour
{

    private const float ZINDEX = -10f;
    private const float MAXSPEED = 100f;

    private bool _isGaming = true;
    private float _size = 26.26f;
    private float _moveTimer = 0f;
    private Vector3 _moveTarget;
    private Vector3 _moveSpeed;
    private float _moveTime;
    private float _sizeTimer = 0f;

    private GameObject player = null;
    private Vector3 _targetPos;
    private Vector3 _cameraSpeed = Vector3.zero;

    public float SMOOTHTIME = 0.1f;

    private void Start()
    {
        player = GameObject.Find("Player");
    }

    public void isShowing(bool inp)
    {
        if (inp == true)
        {
            _isGaming = false;
        }else
        {
            _isGaming = true;
        }
    }

    private void Update()
    {
        if (_isGaming)
        {
            _targetPos = new Vector3(player.transform.position.x, player.transform.position.y, ZINDEX);
            transform.position = Vector3.SmoothDamp(transform.position, _targetPos, ref _cameraSpeed, SMOOTHTIME);
        }
        else
        {
            if (_moveTimer > 0)
            {
                _updatePosition();
            }
        }
        // _updatePosition();
    }

    private void _updatePosition()
    {
        transform.position = Vector3.Lerp(transform.position, _moveTarget, _moveTime*Time.deltaTime);
        _moveTimer -= Time.deltaTime;
        if (_moveTimer < 0)
        {
            _moveTimer = 0;
        }
    }

    public void Move(Vector3 target, Vector3 speed, float time)
    {
        if (_moveTimer != 0)
        {
            return;
        }
        _moveTarget = target;
        _moveSpeed = speed;
        _moveTime = time;
        _moveTimer = time;
    }

    public void Size(float size,float time = 0)
    {

    }
}
