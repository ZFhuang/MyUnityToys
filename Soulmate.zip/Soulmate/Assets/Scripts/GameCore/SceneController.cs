﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneController : MonoBehaviour {
    private Component SceneScript;
    private int _CoinPoint = 0;
    private int _PlayerHP = 100;
	
	void Start () {
        SceneScript = gameObject.GetComponent<Perform_Spt>();
        SceneScript.GetComponent<Perform_Spt>().startShow();
	}
	
    public void GetCoin(int inp=1)
    {
        _CoinPoint += inp;
        print(_CoinPoint);
    }
	
	void Update () {
		
	}
}
