﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PlayerWeapon
{
    public class PlayerWeapon : MonoBehaviour
    {

        private enum State
        {
            nothing = 0,
            flySword = 1,
        }

        [SerializeField]
        private State _state = State.nothing;
        [SerializeField]
        private int restUse = 0;

        public void GetWeapon(string weaponName)
        {
            switch (weaponName)
            {
                
            }
        }
        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }

    public class FlySword : MonoBehaviour
    {

    }
}
