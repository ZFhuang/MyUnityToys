﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DragonBones;

public class Coin : MonoBehaviour {
    private bool _canPick = true;
    private SceneController Scene;
    private UnityArmatureComponent _armatureComponent;

    private void Start()
    {
        Scene = GameObject.Find("SceneController").GetComponent<SceneController>();
        _armatureComponent= this.gameObject.GetComponent<UnityArmatureComponent>();
        _armatureComponent.animation.Reset();
        _armatureComponent.animation.FadeIn("Idle", -1, -1);
    }
    public void Get()
    {
        if (_canPick)
        {
            _canPick = false;
            Scene.GetCoin();
            _armatureComponent.animation.FadeIn("Picked(8fps", -1.0f, -1);
            Destroy(gameObject, 0.3f);
        }
    }
}
