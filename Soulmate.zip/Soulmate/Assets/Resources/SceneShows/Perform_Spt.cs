﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Perform_Spt : MonoBehaviour {

    private PlayerCamera camera;
    private GameObject player = null;

    private float _sceneTime = 0;
    private int _sceneStep = 0;
    private bool _isStart = false;

    private void Start()
    {
        camera =GameObject.Find("Main Camera").GetComponent<PlayerCamera>();
        player = GameObject.Find("Player");
    }

    public void startShow()
    {
        _isStart = true;
        _sceneStep++;
        camera.GetComponent<PlayerCamera>().isShowing(true);
    }

    public void stopShow()
    {
        if (!_isStart)
        {
            return;
        }
        _isStart = false;
        if (_sceneStep == 0)
        {
            return;
        }
        _sceneStep--;
    }

	void Update () {
        if (_isStart)
        {
            _sceneTime += Time.deltaTime;
        }
        _updateAnimate();
        _updateConversation();
	}

    private void _updateConversation()
    {
        
    }

    private void _updateAnimate()
    {
        if (_sceneTime > 0f&&_sceneStep==1)
        {
            _AnimateStep();
        }
        if (_sceneTime > 2f && _sceneStep == 2)
        {
            _AnimateStep();
        }
        if (_sceneTime > 4f && _sceneStep == 3)
        {
            _AnimateStep();
        }
        if (_sceneTime > 6f && _sceneStep == 4)
        {
            _AnimateStep();
        }
        if (_sceneTime > 8f && _sceneStep == 5)
        {
            _AnimateStep();
        }
        if (_sceneTime > 10f && _sceneStep == 6)
        {
            _AnimateStep();
        }
    }

    private void _AnimateStep()
    {
        switch (_sceneStep)
        {
            case 0:
                break;
            case 1:
                camera.Move(new Vector3(-73, 6, -10), Vector3.zero, 1.5f);
                break;
            case 2:
                camera.Move(new Vector3(3, 3, -10), Vector3.zero, 1.5f);
                break;
            case 3:
                camera.Move(new Vector3(8, 33, -10), Vector3.zero, 1.5f);
                break;
            case 4:
                camera.Move(new Vector3(62, 18, -10), Vector3.zero, 1.5f);
                break;
            case 5:
                camera.Move(new Vector3(90, 42, -10), Vector3.zero, 2f);
                break;
            case 6:
                camera.isShowing(false);
                break;
        }
        _sceneStep++;
    }
}
