﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class theSaber : MonoBehaviour {
    public float Direction= -10f;
    public float speed = 1f;
    public float time = 1f;
    private bool isTrigger = false;
	void Start () {
        Invoke("Saber", time);
        Destroy(gameObject, 10);
    }
    void Saber()
    {
        isTrigger = true;
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            GameObject.Find("respawn").SendMessage("DIE");
        }
    }
    void Update()
    {
        if (isTrigger == true)
        {
            Vector2 newPos = new Vector2(transform.position.x, transform.position.y +Direction);
            transform.position = Vector2.MoveTowards(transform.position, newPos, speed);
        }
    }
}

