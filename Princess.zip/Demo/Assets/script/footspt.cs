﻿using UnityEngine;
using System.Collections;

public class footspt : MonoBehaviour {
    static public bool isGround = false;
    static public bool Control = true;
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Floor")
        {
            isGround = true;
            //GameObject .Find("character"). GetComponent<Animator>().SetBool("jump", false);
        }
    }
}
