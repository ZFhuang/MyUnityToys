﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Flyingthings : MonoBehaviour {
    public float speed = -1200f;
    void Start()
    {
            gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(speed,0f)); 
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            GameObject.Find("respawn").SendMessage("DIE");
        }
        
        if (other.tag == "Sword")
        {
            GameObject.Find("character").SendMessage("flying");
            Destroy(gameObject);
        }
    }
    void Update () {
        if (gameObject.transform.position.x - GameObject.Find("character").transform.position.x <= -30f)
        {
            GameObject.Find("character").SendMessage("flying");
            Destroy(gameObject);
        }
        
    }
}
