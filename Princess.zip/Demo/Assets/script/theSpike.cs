﻿using UnityEngine;
using System.Collections;

public class theSpike : MonoBehaviour {
    private bool isTrigger = false;
    private Vector2 newPos;
    public float transY = 11.36f;
    public float speed = 0.5f;
    void get()
    {
        newPos = new Vector2(transform.position.x, transY);
        isTrigger = true;
    }
    void Update()
    {
        if (isTrigger)
        {
            print("moving");
            transform.position = Vector2.MoveTowards(transform.position, newPos, speed);
        }
    }
}
