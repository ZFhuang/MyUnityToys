﻿using UnityEngine;
using System.Collections;

public class downFloor : MonoBehaviour {
    public float speed = 1f;
    private bool isTrigger = false;
    
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            isTrigger = true;
        }
        if (other.gameObject.tag == "Respawn")
        {
            Destroy(this);
        }
    }
    void Update()
    {
        if (isTrigger == true)
        {
            Vector2 newPos = new Vector2(transform.position.x, transform.position.y - 10f);
            transform.position = Vector2.MoveTowards(transform.position, newPos, speed);
            //footspt.isGround = false;//恶意提高难度，还会导致bug
        }
    }
}
