﻿using UnityEngine;
using System.Collections;

public class UPandDOWN : MonoBehaviour {
    public float Up=10f;
    public float Down=1f;
    public float Speed=1f;
    public float time=1f;
    private bool isUP=true;
    private bool isDOWN=false;
    private Vector3 POSup;
    private Vector3 POSdown;
    void Start()
    {
        POSup = new Vector3(transform.position.x, Up,0);
        POSdown = new Vector3(transform.position.x, Down,0);
    }
    IEnumerator Wait(bool UP,bool DOWN)
    {
        yield return new WaitForSeconds(time);
        if (UP)
        {
            isDOWN = true;
        }
        if (DOWN)
        {
            isUP = true;
        }
    }
    void FixedUpdate()
    {
        if (isUP)
        {
            transform.position = Vector2.MoveTowards(transform.position, POSup, Speed);
            if (gameObject.transform.position == POSup)
            {
                
                isUP = false;
                StartCoroutine(Wait(true,false));
            }
        }
        if (isDOWN)
        {
            transform.position = Vector2.MoveTowards(transform.position, POSdown, Speed);
            if (gameObject.transform.position == POSdown)
            {
                
                isDOWN = false;
                StartCoroutine(Wait(false,true));
            }
        }
    }
}