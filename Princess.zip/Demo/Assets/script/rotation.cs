﻿using UnityEngine;
using System.Collections;

public class rotation : MonoBehaviour {
    public float speed = 1f;

    void Update()
    {
        gameObject.transform.Rotate(0, 0, speed);
    }
}