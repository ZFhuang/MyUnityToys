﻿using UnityEngine;using System.Collections;public class Dsword : MonoBehaviour{    public float speed = 15f;    public float time = 2f;    private GameObject player;    private Vector2 direction;    private float rad;    private float angle;    private bool looking = false;    private bool moving = false;    private bool reSword = true;    public string Dname;    GameObject re;    void Awake()    {        re = GameObject.Find("respawn");        player = GameObject.Find("character");        rad = gameObject.transform.eulerAngles.z * Mathf.Deg2Rad;    }    void Starts()    {        moving = true;
    }    IEnumerator attack()    {        yield return new WaitForSeconds(time);        looking = false;        gameObject.GetComponent<Collider2D>().enabled = true;        speed = 35f;        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(Mathf.Sin(rad) * speed, -Mathf.Cos(rad) * speed);    }    void reDsword()    {        if (reSword)
        {
            re.GetComponent<respawn>().Dnumber += 1;
            if (GameObject.Find(Dname = re.GetComponent<respawn>().Dnames()) != null)
            {
                GameObject.Find(Dname = re.GetComponent<respawn>().Dnames()).SendMessage("Starts");
            }
            else
            {
                GameObject.Find("Shocked").GetComponent<SpriteRenderer>().enabled = true;
                GameObject.Find("Demon").GetComponent<Endling>().Ends();
            }
        }        reSword = false;        StartCoroutine(destory());    }    IEnumerator destory()
    {
        yield return new WaitForSeconds(3);
        Destroy(gameObject);
    }    void OnTriggerEnter2D(Collider2D other)    {        if (other.tag == "Player")        {            re.SendMessage("DIE");        }    }    void Update()    {        if (moving == true)        {            speed -= 0.2f;            gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(-Mathf.Sin(rad) * speed, Mathf.Cos(rad) * speed);        }        if (speed < 0)        {            moving = false;            speed = 0;            looking = true;
            reDsword();        }        if (looking == true)        {
            //计算角度
            angle = Mathf.Rad2Deg * Mathf.Atan((transform.position.y - player.transform.position.y) / (transform.position.x - player.transform.position.x));
            //判断角度所在象限，并进行修正。
            if (transform.position.x - player.transform.position.x < 0)            {                angle = angle + 90;            }            else            {                angle = angle - 90;            }
            //设置物体的自身欧拉角，是物体绕自身坐标系在Z轴，旋转Z度。
            transform.localEulerAngles = new Vector3(0, 0, angle);            rad = gameObject.transform.eulerAngles.z * Mathf.Deg2Rad;            StartCoroutine(attack());        }    }}