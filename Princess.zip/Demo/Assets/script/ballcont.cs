﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
public class ballcont : MonoBehaviour {
    public float x = -100f;
    public float y = 0f;
    public float time = 2.4f;
	void get()
    {
        gameObject.GetComponent<Rigidbody2D>().isKinematic = false;
        gameObject.GetComponent<SpriteRenderer>().enabled = true;
        gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(x,y));
        StartCoroutine(Wait());
    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(time);
        Destroy(gameObject);
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.collider.tag == "Player")
        {
            GameObject.Find("respawn").SendMessage("DIE");
        }
    }
    void Update () {
	
	}
}
