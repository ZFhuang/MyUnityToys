﻿using UnityEngine;
using System.Collections;

public class DwordTri : MonoBehaviour {
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            GameObject.Find("DSaber (1)").SendMessage("Starts");
        }
    }
}
