﻿using UnityEngine;using System.Collections;public class Trigger3 : MonoBehaviour {
    void OnCollisionEnter2D(Collision2D other)    {        if (other.collider.tag == "Player")        {            GameObject.Find("sfloor (28)").GetComponent<SpriteRenderer>().enabled = true;            GameObject.Find("sfloor (29)").GetComponent<SpriteRenderer>().enabled = true;            Invoke("Re", 3f);        }    }    void Re()
    {
        GameObject.Find("sfloor (28)").GetComponent<SpriteRenderer>().enabled = false;
        GameObject.Find("sfloor (29)").GetComponent<SpriteRenderer>().enabled = false;
    }}