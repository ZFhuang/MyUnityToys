﻿using UnityEngine;
using System.Collections;
public class theFlag : MonoBehaviour {
    private GameObject Player;
    private bool locked = false;
    private Transform thisobj;
    public float Speed = 10f;
    private Transform flag;

    void Awake()
    {
        Player = GameObject.Find("character");
        thisobj =gameObject.transform;
        flag = GameObject.Find("Flag").transform;
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.collider.tag == "Player")
        {
            locked = true;
            GameObject.Find("respawn").SendMessage("DIE");
        }
    }

    void Update()
    {
        if (locked == true)
        {
            Player.transform.position = new Vector3(flag.position.x-1, flag.position.y, flag.position.z);
            thisobj.transform.Rotate(0, 0, -Speed);
            if (thisobj.transform.eulerAngles.z <= 58f)
            {
                Speed = -Speed;
            }
            if(thisobj.transform.eulerAngles.z >= 118f)
            {
                Speed = 0f;
                locked = false;
            }
            
        }
    }
}
