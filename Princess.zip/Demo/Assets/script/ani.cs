﻿using UnityEngine;
using System.Collections;

public class ani : MonoBehaviour {

    void OnMouseDown() {
        print("oh");
        Animator animator = gameObject.GetComponent<Animator>();
        animator.SetInteger ("int",5);
        print("a");
    }
    void OnMouseUp()
    {
        Animator animator = gameObject.GetComponent<Animator>();
        animator.SetInteger("int", 0);
    }
}
