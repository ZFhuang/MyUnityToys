﻿using UnityEngine;
using System.Collections;

public class Trigger2 : MonoBehaviour {
    private Vector3 POS;
    public float posi=25f;
    public float speed = 0.6f;
    private bool isTrigger = false;
    void Start()
    {
        POS = new Vector3(transform.position.x, posi, 0);
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            gameObject.GetComponent<UPandDOWN>().enabled = false;
            isTrigger = true;
        }
    }
    void FixedUpdate () {
        if (isTrigger)
        {
            transform.position = Vector2.MoveTowards(transform.position, POS, speed);
        }
    }
}
