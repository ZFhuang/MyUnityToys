﻿using UnityEngine;
using System.Collections;

public class Trigger1 : MonoBehaviour {
    public string names = "Spike";
    public bool isDESTORY = false;
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            GameObject.Find(names).SendMessage("get");
            print("Get!");
            if (isDESTORY)
            {
                Destroy(gameObject);
            }
        }
    }
}
