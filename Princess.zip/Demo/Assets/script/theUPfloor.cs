﻿using UnityEngine;
using System.Collections;

public class theUPfloor : MonoBehaviour {
    public float transY = 2.5f;
    public float speed = 1f;
    private bool isTrigger = false;
    private Vector2 newPos;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            newPos = new Vector2(transform.position.x,transY);
            isTrigger = true;
        }
    }
    void Update()
    {
        if (isTrigger)
        {
            transform.position = Vector2.MoveTowards(transform.position, newPos, speed);
        }
        }
    }

