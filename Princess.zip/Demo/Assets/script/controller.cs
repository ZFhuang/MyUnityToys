﻿using UnityEngine;
using System.Collections;

public class controller : MonoBehaviour {
    [SerializeField]private float MaxSpeed = 6f;
    //public float speed = 20f;（罪恶根源的变量！）
    public float jump = 1300f;
    public float Swordspeed = -15f;
    private Rigidbody2D thisri;
    private GameObject Swords;
    public GameObject flyings;
    //private Animator thisani;
    private bool Sword = false;
    private bool flip = false;
    private bool respawnFly = true;

    void Awake()
    {
        thisri = gameObject.GetComponent<Rigidbody2D>();//为了方便
        Swords = GameObject.Find("sword");
        //thisani = gameObject.GetComponent<Animator>();
    }

    void Start()
    {
        
    }

    void FixedUpdate () {
        if (Input.GetKey(KeyCode.S) && Input.GetKey(KeyCode.H) && Input.GetKey(KeyCode.I) && Input.GetKey(KeyCode.T))
        {
            respawnFly = false;
        }
        if (footspt.Control)
        {
            float movex = Input.GetAxis("Horizontal");
            bool isJump = Input.GetKey(KeyCode.UpArrow)|| Input.GetKey(KeyCode.Space);//跳跃控制
            if (flip == false)//向右
            {
                if (Input.GetKey(KeyCode.Z) && Sword == false && Swords.transform.eulerAngles.z >= 120f)//挥剑
                {
                    Sword = true;
                }
                if (Sword == true)
                {
                    Swords.transform.Rotate(0, 0, Swordspeed);
                    if (Swords.transform.eulerAngles.z <= 45f)
                    {
                        Sword = false;
                    }
                }
                if (Sword == false && Swords.transform.eulerAngles.z <= 125f)
                {
                    Swords.transform.Rotate(0, 0, -Swordspeed);
                }
            }
            if (flip == true)//向左
            {
                if (Input.GetKey(KeyCode.Z) && Sword == false && Swords.transform.eulerAngles.z <= 245f)//挥剑
                {
                    Sword = true;
                }
                if (Sword == true)
                {
                    Swords.transform.Rotate(0, 0, Swordspeed);
                    if (Swords.transform.eulerAngles.z >= 330f)
                    {
                        Sword = false;
                    }
                }
                if (Sword == false && Swords.transform.eulerAngles.z >= 240f)
                {
                    Swords.transform.Rotate(0, 0, -Swordspeed);
                }
            }
            //thisri.velocity = Vector2.right * movex * MaxSpeed;(不要写这行！)
            thisri.velocity = new Vector2(movex * MaxSpeed, thisri.velocity.y);//移动
            //thisri.transform.Translate(movex * MaxSpeed * Time.deltaTime, 0, 0);
            if (footspt.isGround)
            {
                if (movex != 0)
                {
                    //thisani.SetInteger("int", 5);//以下是状态机控制
                }
                else
                {
                    //thisani.SetInteger("int", 0);
                }
                if (isJump)
                {
                    //thisani.SetBool("jump", true);
                    thisri.AddForce(new Vector2(0f, jump));
                    footspt.isGround = false;
                }
            }
            if (Input.GetKey(KeyCode.RightArrow) && !m_FacingRight)//转身
            {
                flip = false;
                Flip();
            }
            else if (Input.GetKey(KeyCode.LeftArrow) && m_FacingRight)
            {
                flip = true;
                Flip();
            }
        }
	}

    private bool m_FacingRight = true;//以下是转身代码

    private void Flip()
    {
        m_FacingRight = !m_FacingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    void flying()
    {
        if (respawnFly)
        {
            Vector2 position = new Vector2((transform.position.x) + 30f, Random.Range(transform.position.y + 7f, transform.position.y - 2f));//范围刷怪
            Instantiate(flyings, position, flyings.transform.rotation);
        }
    }
}
