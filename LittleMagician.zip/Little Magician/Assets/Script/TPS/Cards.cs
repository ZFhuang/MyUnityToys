﻿using UnityEngine;
using System.Collections;

public class Cards : MonoBehaviour
{
    private int[] CardDeck;
    public int[] CardOnHand;
    private bool control = true;
    private float time = 0f;
    public camera ca;
    private GameObject PlayerOBJ;
    public GameObject FB;
    private Vector3 mTargetPos;
    private Rect TimeBar;

    void OnGUI()
    {
        GUI.VerticalScrollbar(TimeBar, 1f, time, 0.0f, 1.0f, GUI.skin.GetStyle("verticalScrollbar"));//蓄力条
        GUILayout.Label("\nHand1 " + CardOnHand[0]);
        GUILayout.Label("Hand2 " + CardOnHand[1]);
        GUILayout.Label("Hand3 " + CardOnHand[2]);
        GUILayout.Label("Hand4 " + CardOnHand[3]);
    }
    void Awake()
    {
        TimeBar = new Rect(20, 100, 20, 200);
        PlayerOBJ = GameObject.Find("PLAYERpos");
        CardDeck = new int[15] { 001, 002, 002, 001, 002, 001, 001, 001, 001, 001, 001, 001, 000, 000, 000 };
        CardOnHand = new int[4];
        RandomHand(0);
        RandomHand(1);
        RandomHand(2);
        RandomHand(3);
    }
    void GetTargetPos(Vector3 pos)//接收鼠标地点
    {
        mTargetPos = pos;
    }
    IEnumerator Stop(float time)//停止的携程
    {
        control = false;
        PlayerOBJ.SendMessage("Ccontrol", control);
        yield return new WaitForSeconds(time);
        control = true;
        PlayerOBJ.SendMessage("Ccontrol", control);
    }
    void Update()//差个平A
    {
        if (control)//使用技能按键的操作
        {
            if (Input.GetKey(KeyCode.Alpha1))
            {
                if (Input.GetMouseButton(0))//按住左键时
                {
                    PlayerOBJ.SendMessage("speed", 15f);//减速
                    if (time >= 1f)//蓄力的计算
                    {
                        time = 0f;
                    }
                    time += 1.5f * Time.deltaTime;
                }
                else
                {
                    PlayerOBJ.SendMessage("speed", 50f);//回原速
                }
                if (Input.GetMouseButtonUp(0))//等待左键放开
                {
                    UseCard(0);
                    RandomHand(0);
                }
            }
            else if (Input.GetKey(KeyCode.Alpha2))
            {
                if (Input.GetMouseButton(0))//按住左键时
                {
                    PlayerOBJ.SendMessage("speed", 15f);
                    if (time >= 1f)
                    {
                        time = 0f;
                    }
                    time += 1.5f * Time.deltaTime;
                }
                else
                {
                    PlayerOBJ.SendMessage("speed", 50f);
                }
                if (Input.GetMouseButtonUp(0))//等待左键放开
                {
                    UseCard(1);
                    RandomHand(1);
                }
            }
            else if (Input.GetKey(KeyCode.Alpha3))
            {
                if (Input.GetMouseButton(0))//按住左键时
                {
                    PlayerOBJ.SendMessage("speed", 15f);
                    if (time >= 1f)
                    {
                        time = 0f;
                    }
                    time += 1.5f * Time.deltaTime;
                }
                else
                {
                    PlayerOBJ.SendMessage("speed", 50f);
                }
                if (Input.GetMouseButtonUp(0))//等待左键放开
                {
                    UseCard(2);
                    RandomHand(2);
                }
            }
            else if (Input.GetKey(KeyCode.Alpha4))
            {
                if (Input.GetMouseButton(0))//按住左键时
                {
                    PlayerOBJ.SendMessage("speed", 15f);
                    if (time >= 1f)
                    {
                        time = 0f;
                    }
                    time += 1.5f * Time.deltaTime;
                }
                else
                {
                    PlayerOBJ.SendMessage("speed", 50f);
                }
                if (Input.GetMouseButtonUp(0))//等待左键放开
                {
                    UseCard(3);
                    RandomHand(3);
                }
            }
            else
            {
                time = 0f;
            }
        }
    }
    void RandomHand(int hand)//抽卡
    {
        CardOnHand[hand] = CardDeck[Random.Range(0, 14)];
    }
    void UseCard(int choose)//使用卡
    {
        time = time % 1f;//蓄力的判定
        print(time);
        if (time >= 0.7f)
        {
            print("Good!");
        }
        else
        {
            print("Oh!");
        }
        switch (CardOnHand[choose])
        {
            case 001://火球的控制代码
                if (ca.magic >= 3)
                {
                    StartCoroutine(Stop(1f));
                    int force = 40;
                    Vector3 position = new Vector3(PlayerOBJ.transform.position.x, PlayerOBJ.transform.position.y + 2f, PlayerOBJ.transform.position.z + 0.2f);
                    Instantiate(FB, position, FB.transform.rotation);
                    Vector3 temp = new Vector3((-(PlayerOBJ.transform.position.x - mTargetPos.x) * 100), 0, -((PlayerOBJ.transform.position.z - mTargetPos.z)) * 100).normalized;
                    GameObject.Find("Fire Ball (1)(Clone)").GetComponent<Rigidbody>().velocity = new Vector3(temp.x * force, 0, temp.z * force);
                    ca.magic -= 3;
                }
                break;
            case 002://冰刺
                break;
            default:
                print("wait");
                break;
        }
    }
}
