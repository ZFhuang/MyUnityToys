﻿using UnityEngine;
using System.Collections;

public class camera : MonoBehaviour {
    public Vector3 Player;
    private float height = 71f;
    public int magic = 10;
    private float magictimer = 3f;
    public GUIStyle labelGUI;
    private Rect magicBar;
    void Start () {
        magicBar = new Rect(50, 100, 20, 200);
    }
    void OnGUI() {
        GUI.skin.label = labelGUI;
        GUI.VerticalScrollbar(magicBar, 10, magic, 0, 10, GUI.skin.GetStyle("verticalScrollbar"));
    }
    void Update () {
        magictimer -=Time.deltaTime;
        if (magictimer <= 0)
        {
            if (magic < 10)
            {
                magic += 1;
            }
            magictimer = 3f;
        }
        if (height < 5f) {
            height = 5f;
        }
        if (height > 80f)
        {
            height = 80f;
        }
        if (height >=5f && height <= 80f)
        {
            if (Input.GetAxis("Mouse ScrollWheel") > 0)
            {
                height -= 1;
            }
            if (Input.GetAxis("Mouse ScrollWheel") < 0)
            {
                height += 1;
            }
        }
        Player = GameObject.FindWithTag("Player").transform.position;
        gameObject.transform.position = new Vector3(Player.x,height,Player.z-48f);
        gameObject.transform.LookAt(Player);
	}
}
