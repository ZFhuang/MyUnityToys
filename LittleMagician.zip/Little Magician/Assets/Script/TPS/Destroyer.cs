﻿using UnityEngine;
using System.Collections;

public class Destroyer : MonoBehaviour {
    public float DestroyTime=0.5f;

	void Update () {
            Destroy(gameObject,DestroyTime);
	}
}
