﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    public float MoveSpeed = 50f;
    public Vector3 mTargetPos;
    private float angle;
    private bool control = true;
    void Start()
    {
    }
    void Update()
    {
        if (control)//操控判定
        {
            //获取屏幕坐标
            Vector3 mScreenPos = Input.mousePosition;
            //定义射线（从摄影机向画面）
            Ray mRay = Camera.main.ScreenPointToRay(mScreenPos);
            RaycastHit mHit;
            //判断射线是否击中地面
            if (Physics.Raycast(mRay, out mHit))//Raycast当击中物体时返回值为1
            {
                mTargetPos = mHit.point; //获取目标坐标!
                GameObject.Find("Main Camera").SendMessage("GetTargetPos", mTargetPos);
            }
            //原理为改变角度（欧拉角）
            angle = Mathf.Rad2Deg * Mathf.Atan(-(transform.position.z - mTargetPos.z) / (transform.position.x - mTargetPos.x));
            //判断角度所在象限，并进行修正（防止旋转时闪动）。
            if (transform.position.x - mTargetPos.x < 0)
            {
                angle = angle + 90;
            }
            else
            {
                angle = angle - 90;
            }
            //设置物体的自身欧拉角，是物体绕自身坐标系的旋转轴（在此为Y轴），在3D场景中欧拉角为四维向量。
            transform.localEulerAngles = new Vector4(0, angle, 0, 0);
            float moveX = Input.GetAxis("Horizontal");
            float moveZ = Input.GetAxis("Vertical");
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(moveX * MoveSpeed, 0, moveZ * MoveSpeed);
        }
        //用velocity移动可以保证可以让玩家边移动边瞄准，但是侧向走因为向量和的原因会变快！
    }
    void speed(float NewSpeed)//速度的对外接口
    {
        MoveSpeed = NewSpeed;
    }
    void Ccontrol(bool select)//操作的对外接口
    {
        if (select)
        {
            control = true;
        }
        else
        {
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);//速度归零
            control = false;
        }
        
    }
}
