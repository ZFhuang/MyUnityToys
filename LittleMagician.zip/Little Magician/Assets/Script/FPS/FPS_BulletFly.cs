﻿using UnityEngine;
using System.Collections;

public class FPS_BulletFly : MonoBehaviour {
    public float flyingSpeed = 10f;

    private bool start = false;
    private Vector3 posi;
	
    // Use this for initialization
	void Start () {
        Destroy(gameObject, 0.5f);
	}
	public void getTarget(Vector3 pos)
    {
        posi = pos;
        start = true;
    }
    // Update is called once per frame
    void Update()
    {
        if (start)
        {
            transform.position = Vector3.MoveTowards(transform.position,posi,1f);
        }
    }
}
