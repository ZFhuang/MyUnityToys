﻿using UnityEngine;using System.Collections;public class FPS_PlayerController : MonoBehaviour{    public float MoveSpeed = 0.15f;//移动速度    public static float oriGravity = -0.01f;//防止直接高速落地或出现一帧的高速落地    [SerializeField]    private float Gravity=-0.75f;//重力    private int HP;    private CharacterController CharaterCon;    private bool isJumping = false;    private bool isControl = true;    public GameObject Card1;    public GameObject Card2;    private GameObject Card3;    private GameObject Card4;    void Start()    {        HP = 100;        CharaterCon = GetComponent<CharacterController>();//用这个组件来移动（其实并不是很喜欢）::(不，它好用到爆)    }    /// <summary>
    /// 1 =>完全冷冻（睡眠）状态
    /// </summary>
    /// <param name="condi"></param>
    public void Condition(int condi)
    {
        switch (condi)
        {
            case 1:
                isControl = false;
                break;
        }
    }    public void Damage(int damage)//伤害代码    {        HP -= damage;        Debug.Log(HP);        if (HP <= 0)        {            GameObject.Find("SenceController").SendMessage("GameOver");        }    }    void Update()    {        if (isControl)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                Card2.SendMessage("Get", false);
                Card1.SendMessage("Get", true);
            }
            else if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                Card1.SendMessage("Get", false);
                Card2.SendMessage("Get", true);
            }
            StartCoroutine(IE_Grounded());
            if (Input.GetKeyDown(KeyCode.Space) && CharaterCon.isGrounded && Gravity == oriGravity)//跳跃
            {
                isJumping = true;
                StartCoroutine(IE_Jump());
            }
            if (isJumping == false && CharaterCon.isGrounded)
            {
                Gravity = oriGravity;//落地时
            }
            float deltaX = Input.GetAxis("Horizontal") * MoveSpeed;//获取输入方向
            float deltaZ = Input.GetAxis("Vertical") * MoveSpeed;
            Vector3 movement = new Vector3(deltaX, 0, deltaZ);
            movement = Vector3.ClampMagnitude(movement, MoveSpeed);
            movement.y = Gravity;//重力模拟
            movement = transform.TransformDirection(movement);//移动模拟
            CharaterCon.Move(movement);//调用这个组件的函数
        }
    }    IEnumerator IE_Grounded()//判断若先是在地面，下一帧不在，则确定为下落中（没有发生跳跃）    {        if (isJumping==false)        {            if (CharaterCon.isGrounded)            {                yield return 0;                if (isJumping == false)                {                    if (CharaterCon.isGrounded == false)                    {                        StartCoroutine(IE_Falling());                    }                }            }        }    }    IEnumerator IE_Falling()//下落的代码。其实就是跳跃的后半段    {        Gravity = -0.05f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.07f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.2f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.31f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.45f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.75f;    }    IEnumerator IE_Jump()//用代码模拟跳跃，不真实但是好看    {        Gravity = 0.45f;        yield return new WaitForSeconds(0.05f);        Gravity = 0.35f;        yield return new WaitForSeconds(0.05f);        Gravity = 0.2f;        yield return new WaitForSeconds(0.05f);        Gravity = 0.1f;        yield return new WaitForSeconds(0.05f);        Gravity = 0.08f;        yield return new WaitForSeconds(0.05f);        Gravity = 0.05f;        yield return new WaitForSeconds(0.05f);        Gravity = 0;        yield return new WaitForSeconds(0.05f);        Gravity = -0.07f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.2f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.31f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.45f;        yield return new WaitForSeconds(0.05f);        Gravity = -0.75f;        isJumping = false;    }}