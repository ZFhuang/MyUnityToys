﻿using UnityEngine;using System.Collections;public class FPS_RayShooter : MonoBehaviour{    public bool HitholeEnable = true;//弹孔开关
    public float ReloadTime = 1.5f;    public int TimeOfHithole = 1;//弹孔留存时间

    private GameObject pointer;
    private Camera Cam;
    private bool hasBullet = true;
    private bool isSelect = false;
    private bool isFire = false;    private int Front_sightsSize = 48;//准星大小
    private int BulletNum = 30;

    [SerializeField]
    private float XrandomShoot = 10f;
    [SerializeField]
    private float YrandomShoot = 10f;
    [SerializeField]    private float shootTIME = 0.1f;    [SerializeField]    private GameObject Hithole;    [SerializeField]    private GameObject Bullet;
    
    void Start()    {        pointer = GameObject.Find("pointer");        BulletNum = 30;        Cam = GameObject.Find("Main Camera").GetComponent<Camera>();
    }    void OnGUI()    {        if (isSelect)
        {
            float posX = Cam.pixelWidth / 2;//中心点
            float posY = Cam.pixelHeight / 2;
            GUI.Label(new Rect(posX, posY, Front_sightsSize, Front_sightsSize), "+");//用加号来做准星
        }
    }
    public void Get(bool selection)
    {
        isSelect = selection;
    }
    void FixedUpdate()    {        if (isSelect)
        {
            if (BulletNum <= 0)
            {
                hasBullet = false;
            }
            if (Input.GetMouseButtonDown(0))
            {
                isFire = true;
                StartCoroutine(IE_HandTremor());//枪模型的抖动，建议用动画代替
            }
            if (Input.GetMouseButtonUp(0))
            {
                isFire = false;
            }
            if (Input.GetKeyDown(KeyCode.R) && BulletNum < 30 && hasBullet == true || Input.GetKeyDown(KeyCode.R) && BulletNum <= 0)//防止错误装填
            {
                StartCoroutine(IE_ReLoadBullet());
            }
            if (Input.GetMouseButton(0) && hasBullet)
            {
                Shoot();
            }
        }    }    void Shoot()    {        Vector3 Point = new Vector3(Cam.pixelWidth / 2+Random.Range(-XrandomShoot,XrandomShoot), Cam.pixelHeight / 2 + Random.Range(-YrandomShoot,YrandomShoot), 0);//屏幕中心坐标（附带弹道偏移）
        Ray shoot = Cam.ScreenPointToRay(Point);        RaycastHit Hit;

        if (HitholeEnable && Physics.Raycast(shoot, out Hit))        {            StartCoroutine(IE_Shoot(Hit));        }    }    private IEnumerator IE_HandTremor()
    {
        Vector3 pointerOri = pointer.transform.localPosition;
        while (true)
        {
            Vector3 pointerPo = new Vector3(pointer.transform.localPosition.x + 0.1f, pointer.transform.localPosition.y + 0.1f, pointer.transform.localPosition.z);
            pointer.transform.localPosition = Vector3.MoveTowards(pointer.transform.localPosition, pointerPo, 0.1f);
            yield return new WaitForSeconds(0.5f);
            pointer.transform.localPosition = pointerOri;
            if (isFire == false)
            {
                yield break;
            }
        }
    }    private IEnumerator IE_ReLoadBullet()    {        hasBullet = false;        Debug.Log("Reloading...");
        yield return new WaitForSeconds(ReloadTime);        Debug.Log("Reloaded!");        BulletNum = 30;        hasBullet = true;    }    private IEnumerator IE_hitHole(Vector3 position)    {        GameObject tempHithole = Instantiate(Hithole);//生成弹孔
        tempHithole.transform.position = position;        tempHithole.transform.LookAt(gameObject.transform);
        //tempHithole.GetComponent<Collider>().enabled = false;//关闭弹孔的碰撞
        yield return new WaitForSeconds(TimeOfHithole);//等待携程
        Destroy(tempHithole);    }    private IEnumerator IE_Shoot(RaycastHit Hit)    {        hasBullet = false;
        yield return new WaitForSeconds(shootTIME);

        GameObject flyingBullet = Instantiate(Bullet) as GameObject;        flyingBullet.transform.position = pointer.transform.position;        flyingBullet.GetComponent<FPS_BulletFly>().getTarget(Hit.point);//创造飞行轨迹（挺丑的）

        BulletNum -= 1;//子弹减一
        Debug.Log(BulletNum);        hasBullet = true;

        GameObject hitObject = Hit.transform.gameObject;        FPS_EnemyCube target = hitObject.GetComponent<FPS_EnemyCube>();//弹孔
        if (target != null)        {            target.BeHit(20);//不知道和SendMessage哪个好
        }

        StartCoroutine(IE_hitHole(Hit.point));//开始携程
        yield return 0;
    }
}