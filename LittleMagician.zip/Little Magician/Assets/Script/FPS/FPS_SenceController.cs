﻿using UnityEngine;using System.Collections;public class FPS_SenceController : MonoBehaviour
{
    [SerializeField]
    private GameObject PrefabEnemy;
    private GameObject Enemy;
    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (Enemy == null)
        {
            Enemy = Instantiate(PrefabEnemy) as GameObject;
            Enemy.tag = "Enemy";
            Enemy.transform.position = new Vector3(0f, 1.461f, -2.72f);
            float angle = Random.Range(0, 360);
            Enemy.transform.Rotate(0, angle, 0);
        }
    }    public void GameOver()
    {
        Time.timeScale = 0;
    }}