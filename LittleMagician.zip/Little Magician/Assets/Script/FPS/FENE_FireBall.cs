﻿using UnityEngine;using System.Collections;public class FENE_FireBall : MonoBehaviour {    public float speed = 4f;    public int damage = 20;

    private GameObject player;	    // Use this for initialization	void Start () {
        player = GameObject.FindWithTag("Player");
        gameObject.tag = "Enemy";        gameObject.transform.LookAt(GameObject.FindWithTag("Player").gameObject.transform);	}		// Update is called once per frame	void Update () {        transform.Translate(0, 0, speed * Time.deltaTime);	}    void OnTriggerEnter(Collider other)    {
        if (other.tag != "Enemy")
        {
            if (other.tag == "Player")
            {
                player.SendMessage("Damage",20);
                Debug.Log("Hit!");
            }
            Destroy(gameObject);
        }    }}