﻿using UnityEngine;using System.Collections;public class FPS_EnemyCube : MonoBehaviour
{    public float Speed = 3.0f;    public float ObstacleRange = 5.0f;    private bool isAlive = true;    private int Life = 100;
    [SerializeField]//使一个private显示在inspector中
    private float WatchingRange = 0.75f;
    [SerializeField]
    private GameObject FireballPrefab;
    [SerializeField]
    private int fireballNum = 3;
    private GameObject fireball;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()    {        if (isAlive)        {            transform.Translate(0, 0, Speed * Time.deltaTime);            Ray ray = new Ray(transform.position, transform.forward);            RaycastHit hit;            if (Physics.SphereCast(ray, WatchingRange, out hit))//球形射线探测器
            {                GameObject hitObject = hit.transform.gameObject;                if (hitObject.tag=="Player")
                {
                    if (fireball == null)
                    {
                        StartCoroutine(Attack(fireballNum));
                    }
                    else if (hit.distance < ObstacleRange * 2)
                    {
                        float angle = Random.Range(-110, 110);
                        transform.Rotate(0, angle, 0);
                    }
                }
                               if (hit.distance < ObstacleRange)                {                    float angle = Random.Range(-150, 150);//转向角度
                    transform.Rotate(0, angle, 0);                }            }        }    }    IEnumerator Attack(int i)
    {
        yield return new WaitForSeconds(0.5f);
        fireball = Instantiate(FireballPrefab) as GameObject;
        fireball.transform.position = transform.TransformPoint(Vector3.forward * 1.5f);
        fireball.transform.rotation = transform.rotation;
        if (i >= 1)
        {
            StartCoroutine(Attack(i - 1));
        }
    }    public void BeHit(int damege)    {        Life -= damege;//伤害
        if (Life <= 0)        {            StartCoroutine(Die());        }    }    IEnumerator Die()    {        isAlive = false;        this.transform.Rotate(-75, 0, 0);//使倒下
        this.gameObject.layer = 2;//设置layer为无视射线的一层
        for (int i = 0; i < 5; i++)//用个循环来完成闪动效果
        {
            yield return new WaitForSeconds(0.2f);
            this.GetComponent<Renderer>().enabled = false;
            yield return new WaitForSeconds(0.2f);
            this.GetComponent<Renderer>().enabled = true;
        }        Destroy(this.gameObject);    }}