﻿using UnityEngine;
using System.Collections;

public class C002_FlyingTO : MonoBehaviour {
    private GameObject player;
    private Camera Cam;
    private bool isSelect = false;
    private int Front_sightsSize = 48;//准星大小
    private bool start = false;

    void Start () {
        Cam = GameObject.Find("Main Camera").GetComponent<Camera>();
        player = GameObject.FindWithTag("Player");
    }

    void OnGUI()    {        if (isSelect)
        {
            float posX = Cam.pixelWidth / 2;//中心点
            float posY = Cam.pixelHeight / 2;
            GUI.Label(new Rect(posX, posY, Front_sightsSize, Front_sightsSize), "*");//准星
        }
    }

    public void Get(bool selection)
    {
        isSelect = selection;
    }

    void Update () {
        if (isSelect)
        {
            Vector3 target=new Vector3();
            if (Input.GetMouseButtonDown(0)&&start==false)
            {
                RaycastHit Hit;
                Vector3 Point = new Vector3(Cam.pixelWidth / 2, Cam.pixelHeight / 2, 0);//屏幕中心坐标
                Ray shoot = Cam.ScreenPointToRay(Point);
                

                if (Physics.Raycast(shoot, out Hit))
                {
                    target = Hit.transform.position;
                    start = true;
                }
            }
            if (start)
            {
                player.transform.position = Vector3.MoveTowards(player.transform.position, target, 1f);
                if (true) {///用范围来判断是否达到吧！
                    start = false;
                }
            }
        }
        
	}

}
