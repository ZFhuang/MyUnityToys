﻿using UnityEngine;
using System.Collections;

public class OnLook : MonoBehaviour
{
    public GameObject now;
    public GameObject tempnow;
    private GameObject TheDeck;
    // Use this for initialization
    void Start()
    {
        TheDeck = GameObject.Find("Select");
        PlayerPrefs.DeleteAll();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mScreenPos = Input.mousePosition;
        Ray mRay = Camera.main.ScreenPointToRay(mScreenPos);
        RaycastHit mHit;
        if (Physics.Raycast(mRay, out mHit))//Raycast当击中物体时返回值为1
        {
            now = GameObject.Find(mHit.transform.gameObject.name);
            if (mHit.transform.gameObject.tag == "Card")
            {
                if (Input.GetMouseButtonDown(0))
                {
                    tempnow.transform.name = now.transform.name;
                    tempnow.transform.localScale = now.transform.localScale;
                    tempnow.transform.position = now.transform.position;
                }
                if (mHit.transform.gameObject.name == tempnow.name && Input.GetMouseButton(0))//Raycast当击中物体时返回值为1
                {
                    now.transform.position = new Vector3(mHit.point.x, mHit.point.y, -0.4f);
                    now.transform.localScale = new Vector3(0.2f, 2, 0.3f);
                }
                else if (Input.GetMouseButtonUp(0))
                {
                    if (now.transform.position.x >= 3.5f && now.transform.position.x <= 6f && now.transform.position.y >= -3.5f && now.transform.position.y <= 5f)
                    {
                        TheDeck.SendMessage("isEnter", tempnow.transform.name);
                    }
                    now.transform.localScale = tempnow.transform.localScale;
                    now.transform.position = tempnow.transform.position;
                }
                else if (Input.GetMouseButtonUp(1))
                {
                    tempnow.transform.name = now.transform.name;
                    TheDeck.SendMessage("isEnter", tempnow.transform.name);
                }
            }
            else if (mHit.transform.tag == "CardIN")
            {
                if (Input.GetMouseButtonDown(0))
                {
                    tempnow.transform.name = now.transform.name;
                    tempnow.transform.localScale = now.transform.localScale;
                    tempnow.transform.position = now.transform.position;
                }
                if (mHit.transform.gameObject.name == tempnow.name && Input.GetMouseButton(0))//Raycast当击中物体时返回值为1
                {
                    now.transform.position = new Vector3(mHit.point.x, mHit.point.y, -0.4f);
                    now.transform.localScale = new Vector3(0.2f, 2, 0.3f);
                }
                else if (Input.GetMouseButtonUp(0))
                {
                    if (now.transform.position.x <= 3.5f || now.transform.position.x >= 6f || now.transform.position.y <= -3.5f || now.transform.position.y >= 5f)
                    {
                        string tempName = now.name;
                        Destroy(now);
                        TheDeck.SendMessage("isOuter", tempName);
                    }
                    else
                    {
                        now.transform.localScale = tempnow.transform.localScale;
                        now.transform.position = tempnow.transform.position;
                    }
                }
                else if (Input.GetMouseButtonDown(1))
                {
                    string tempName = now.name;
                    Destroy(now);
                    TheDeck.SendMessage("isOuter", tempName);
                }
            }
        }
    }
}
