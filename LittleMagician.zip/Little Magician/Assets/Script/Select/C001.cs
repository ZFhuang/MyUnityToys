﻿using UnityEngine;
using System.Collections;

public class C001 : MonoBehaviour {
    public GameObject theboom;
    private float timer;
	void Start () {
        timer = 2f;
    }
	
	// Update is called once per frame
	void Update () {
        timer -= 1 * Time.deltaTime;
        if (timer <= 0f)
        {
            gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
            Instantiate(theboom, gameObject.transform.position, gameObject.transform.rotation);
            Destroy(gameObject);
        }
        
	}
}
